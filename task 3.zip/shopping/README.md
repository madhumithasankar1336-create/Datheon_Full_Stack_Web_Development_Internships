# PINK BLOOM

A premium pink e-commerce demo built with **only HTML5, CSS3 and vanilla JavaScript (ES modules)** — no frameworks, no build step.
Products come live from [FakeStore API](https://fakestoreapi.com). Checkout is a **simulated demonstration**: no card details are requested and no payment is processed.

## Run it
JavaScript modules need an HTTP server (don't open `index.html` via `file://`):

```bash
cd pink-bloom
python -m http.server 5500
```
Then open http://localhost:5500

## Run the tests (optional, needs Node 18+)
```bash
npm install      # installs jsdom for the DOM integration test only
npm test
```

## Structure
```
index.html          page markup (hero, shop, collections, about, cart drawer, checkout modal)
css/style.css       theme variables, layout, animations, responsive rules
js/app.js           wiring: rendering, search, filters, sorting, drawer, nav
js/api.js           fetch + validation + caching of FakeStore data
js/products.js      filtering/sorting logic and product card
js/cart.js          cart state and operations
js/calculations.js  money maths in integer cents (8% tax, $5.99 shipping under $50)
js/storage.js       validated localStorage persistence
js/checkout.js      checkout modal, validation, order reference
js/utils.js         safe DOM builder, formatting, overlay/focus-trap helper
tests/              node:test unit tests + jsdom integration test (mocked API)
```

## Notes
- Brand pink `#FF3F8E` / hot pink `#F72585` on white are below WCAG AA contrast for small text, so text and button fills use a slightly deeper `--pink-ink` (`#D4146C`). The palette variables are all defined in `:root`.
- All API text is inserted with `textContent` (no `innerHTML`). Broken images fall back to a branded placeholder.
