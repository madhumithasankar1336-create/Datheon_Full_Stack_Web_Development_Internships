import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateSubtotal, calculateTax, calculateShipping, calculateTotal, calculateLineTotal } from '../js/calculations.js';
import { filterProducts } from '../js/products.js';
import { normalizeProduct } from '../js/api.js';
import { validateCheckout, generateOrderRef } from '../js/checkout.js';
import { PRODUCTS } from './helpers.mjs';

const it = (price, quantity) => ({ price, quantity });
test('empty cart is all zero', () => {
  assert.equal(calculateSubtotal([]), 0); assert.equal(calculateShipping([]), 0); assert.equal(calculateTotal([]), 0);
});
test('shipping rules: <$50 charged, =$50 and above free', () => {
  assert.equal(calculateShipping([it(49.99, 1)]), 5.99);
  assert.equal(calculateShipping([it(50, 1)]), 0);
  assert.equal(calculateShipping([it(25, 2)]), 0);
});
test('no floating-point drift (0.1 + 0.2 style)', () => {
  assert.equal(calculateSubtotal([it(0.1, 1), it(0.2, 1)]), 0.3);
  assert.equal(calculateLineTotal(19.99, 3), 59.97);
});
test('tax 8% and grand total', () => {
  const items = [it(22.3, 2), it(10.99, 1)]; // 55.59
  assert.equal(calculateSubtotal(items), 55.59);
  assert.equal(calculateTax(items), 4.45);
  assert.equal(calculateTotal(items), 60.04);
  const small = [it(10, 1)];
  assert.equal(calculateTotal(small), 16.79); // 10 + 0.80 + 5.99
});
test('invalid prices/quantities are ignored safely', () => {
  assert.equal(calculateSubtotal([it(-5, 1), it('x', 2), it(10, 0), it(10, 1.5), null, it(10, 1)]), 10);
});
test('normalizeProduct validates and defaults', () => {
  assert.equal(normalizeProduct({ id: 'bad', price: 'abc' }), null);
  const p = normalizeProduct(PRODUCTS[3]);
  assert.equal(p.rating, null); assert.equal(p.image, '');
  assert.equal(normalizeProduct(PRODUCTS[2]).image, '');
});
test('search/filter/sort', () => {
  const list = PRODUCTS.map(normalizeProduct).filter(Boolean);
  assert.deepEqual(filterProducts(list, { query: '  PINK   silk ' }).map((p) => p.id), [1]);
  assert.deepEqual(filterProducts(list, { query: 'jewel' }).map((p) => p.id), [2]);
  assert.deepEqual(filterProducts(list, { category: 'electronics', query: 'usb' }).map((p) => p.id), [3]);
  assert.deepEqual(filterProducts(list, { query: 'zzz' }), []);
  assert.deepEqual(filterProducts(list, { sort: 'price-asc' }).map((p) => p.id), [3, 1, 4, 2]);
  assert.deepEqual(filterProducts(list, { sort: 'price-desc' }).map((p) => p.id), [2, 4, 1, 3]);
  assert.deepEqual(filterProducts(list, { sort: 'rating-desc' }).map((p) => p.id)[0], 3);
});
test('checkout validation', () => {
  assert.deepEqual(Object.keys(validateCheckout({})).sort(), ['address', 'city', 'email', 'name', 'postal']);
  assert.ok(validateCheckout({ name: 'A B', email: 'nope', address: '1 Main St', city: 'X Y', postal: '12345' }).email);
  assert.deepEqual(validateCheckout({ name: 'Ann Lee', email: 'ann@ex.com', address: '1 Main St', city: 'Rome', postal: '600 001' }), {});
  assert.notEqual(generateOrderRef(), generateOrderRef());
});
