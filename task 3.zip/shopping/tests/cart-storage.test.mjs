import test from 'node:test';
import assert from 'node:assert/strict';

const store = new Map();
globalThis.localStorage = { getItem: (k) => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)), removeItem: (k) => store.delete(k) };
store.set('pinkbloom.cart.v1', '{not json');
const warn = console.warn; console.warn = () => {};
const cart = await import('../js/cart.js');
console.warn = warn;

test('malformed saved cart does not crash and is cleared', () => {
  assert.equal(cart.getCount(), 0);
  assert.equal(store.has('pinkbloom.cart.v1'), false);
});
test('add, duplicate, quantity ops, remove, clear, persistence', () => {
  const p = { id: 7, title: 'Thing', price: 12.5, image: '', category: 'x' };
  assert.equal(cart.addToCart(p), true); assert.equal(cart.addToCart(p), true);
  assert.equal(cart.getCount(), 2); assert.equal(cart.getItems().length, 1);
  assert.equal(cart.calculateSubtotal(), 25);
  cart.increaseQuantity(7); assert.equal(cart.getCount(), 3);
  cart.decreaseQuantity(7); cart.decreaseQuantity(7); assert.equal(cart.decreaseQuantity(7), false); assert.equal(cart.getCount(), 1);
  assert.equal(cart.updateQuantity(7, 'abc'), false); assert.equal(cart.updateQuantity(7, 2.5), false);
  cart.updateQuantity(7, 500); assert.equal(cart.getCount(), 99);
  assert.equal(cart.addToCart(p), false);
  assert.equal(JSON.parse(store.get('pinkbloom.cart.v1'))[0].quantity, 99);
  assert.equal(cart.addToCart({ id: 8, price: 'x' }), false);
  cart.removeFromCart(7); assert.equal(cart.getCount(), 0);
  cart.addToCart(p); cart.clearCart(); assert.equal(cart.getCount(), 0);
});
test('storage sanitising: bad entries dropped, duplicates merged', async () => {
  const { loadCart } = await import('../js/storage.js');
  store.set('pinkbloom.cart.v1', JSON.stringify([{ id: 1, price: 5, quantity: 2 }, { id: 1, price: 5, quantity: 3 }, { id: 2, price: -1, quantity: 1 }, { id: 3, price: 1, quantity: 0 }, 'x', null]));
  const out = loadCart(); assert.equal(out.length, 1); assert.equal(out[0].quantity, 5);
});
test('localStorage that throws does not crash', async () => {
  globalThis.localStorage = { getItem() { throw new Error('denied'); }, setItem() { throw new Error('quota'); }, removeItem() { throw new Error('denied'); } };
  const w = console.warn; console.warn = () => {};
  const { loadCart, saveCart } = await import('../js/storage.js');
  assert.deepEqual(loadCart(), []); assert.equal(saveCart([]), false);
  console.warn = w;
});
