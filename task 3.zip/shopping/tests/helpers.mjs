export const PRODUCTS = [
  { id: 1, title: 'Pink Silk Shirt', price: 22.3, category: "women's clothing", image: 'https://x.test/1.jpg', rating: { rate: 4.1, count: 259 } },
  { id: 2, title: 'Gold Ring', price: 695, category: 'jewelery', image: 'https://x.test/2.jpg', rating: { rate: 3.9, count: 70 } },
  { id: 3, title: 'USB Drive', price: 10.99, category: 'electronics', image: 'not-a-url', rating: { rate: 4.8, count: 12 } },
  { id: 4, title: '<img src=x onerror=alert(1)>', price: 30, category: 'electronics' }, // hostile title, no rating/image
  { id: 'bad', title: 'Broken', price: 'abc' }, // malformed: must be skipped
  null,
];
export const CATS = ['electronics', 'jewelery', "women's clothing"];
export const json = (data) => ({ ok: true, status: 200, json: async () => data });
