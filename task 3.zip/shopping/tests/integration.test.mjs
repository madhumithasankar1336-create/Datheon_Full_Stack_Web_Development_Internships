import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { JSDOM } from 'jsdom';
import { PRODUCTS, CATS, json } from './helpers.mjs';
import { EXTRA_PRODUCTS } from '../js/catalog.js';
const TOTAL = 4 + EXTRA_PRODUCTS.length;
const NEW_CATS = [...new Set(EXTRA_PRODUCTS.map((p) => p.category))];

const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const dom = new JSDOM(html, { url: 'http://localhost:5500/', pretendToBeVisual: true });
const { window } = dom;
Object.assign(globalThis, { window, document: window.document, localStorage: window.localStorage });
window.HTMLElement.prototype.scrollIntoView = () => {};
window.localStorage.setItem('pinkbloom.cart.v1', 'garbage{{'); // invalid saved cart before boot
let productCalls = 0; let failFirst = true;
globalThis.fetch = async (url) => {
  if (url.endsWith('/products/categories')) return json(CATS);
  productCalls++;
  if (failFirst) { failFirst = false; throw new TypeError('Failed to fetch'); }
  return json(PRODUCTS);
};
const origWarn = console.warn; const origErr = console.error; const errors = [];
console.warn = () => {}; console.error = (...a) => errors.push(a);

const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const type = async (input, v) => { input.value = v; input.dispatchEvent(new window.Event('input', { bubbles: true })); await sleep(200); };
const cards = () => [...document.querySelectorAll('#product-grid .card')];
const titles = () => cards().map((c) => c.querySelector('.card__title').textContent);
const addBtn = (t) => cards().find((c) => c.querySelector('.card__title').textContent === t).querySelector('button');
const key = (k) => document.dispatchEvent(new window.KeyboardEvent('keydown', { key: k, bubbles: true }));

await import('../js/app.js').then((m) => m.ready);

test('failed API shows error + retry; retry loads products; malformed items skipped', async () => {
  assert.match($('product-status').textContent, /couldn't load/i);
  assert.equal(cards().length, 0);
  $('retry-btn').click(); await sleep(50);
  assert.equal(productCalls, 2);
  assert.equal(cards().length, TOTAL); // 2 malformed API entries skipped, catalog added
  assert.equal($('product-status').hidden, true);
  assert.equal(document.querySelectorAll('#category-filters .chip').length, 1 + CATS.length + NEW_CATS.length);
  assert.equal(document.querySelector('#product-grid img[src^="data:"]') !== null, true); // fallback image used
});
test('hostile title rendered as text, not HTML', () => {
  assert.equal(document.querySelector('#product-grid img[onerror]'), null);
  assert.ok(titles().includes('<img src=x onerror=alert(1)>'));
});
test('invalid saved cart ignored: badge hidden, empty message shown', () => {
  assert.equal($('cart-badge').hidden, true); assert.equal($('cart-empty').hidden, false);
});
test('search, clear, no-match message, category filter, sorting', async () => {
  await type($('search-input'), '  SHIRT ');
  assert.deepEqual(titles(), ['Pink Silk Shirt']); assert.equal($('search-clear').hidden, false);
  await type($('search-input'), 'zzzz');
  assert.equal(cards().length, 0); assert.match($('product-status').textContent, /No products match/);
  $('search-clear').click(); await sleep(10);
  assert.equal(cards().length, TOTAL); assert.equal($('search-input').value, '');
  [...document.querySelectorAll('.chip')].find((c) => c.textContent === 'Electronics').click();
  assert.equal(cards().length, 2);
  assert.equal(document.querySelector('.chip.is-active').textContent, 'Electronics');
  await type($('search-input'), 'usb'); assert.deepEqual(titles(), ['USB Drive']);
  $('search-clear').click(); document.querySelector('.chip').click();
  $('sort-select').value = 'price-desc'; $('sort-select').dispatchEvent(new window.Event('change'));
  assert.equal(titles()[0], 'Gold Ring');
  $('sort-select').value = 'price-asc'; $('sort-select').dispatchEvent(new window.Event('change'));
  assert.equal(titles()[0], 'USB Drive');
  document.querySelector('.chip').click(); assert.equal($('sort-select').value, 'price-asc'); // sort preserved
});
test('navbar Categories menu lists every category and filters the shop', () => {
  assert.ok(EXTRA_PRODUCTS.length >= 36);
  $('nav-cat-toggle').click();
  assert.equal($('nav-cat-list').hidden, false); assert.equal($('nav-cat-toggle').getAttribute('aria-expanded'), 'true');
  const items = [...document.querySelectorAll('#nav-cat-list .menu-item')];
  assert.equal(items.length, 1 + CATS.length + NEW_CATS.length);
  items.find((b) => b.textContent === 'Home Decor').click();
  assert.equal($('nav-cat-list').hidden, true);
  assert.equal(cards().length, 6); assert.equal(document.querySelector('.chip.is-active').textContent, 'Home Decor');
  document.querySelector('.chip').click(); assert.equal(cards().length, TOTAL);
});
test('empty-cart checkout is prevented', () => {
  $('checkout-btn').click(); // drawer hidden but handler must still guard
  assert.equal($('checkout-overlay').classList.contains('is-open'), false);
});
test('cart: add, duplicate, badge, drawer totals, qty controls, remove, persistence', () => {
  addBtn('USB Drive').click(); addBtn('USB Drive').click(); addBtn('Pink Silk Shirt').click();
  assert.equal($('cart-badge').textContent, '3');
  $('cart-button').click();
  assert.equal($('cart-overlay').classList.contains('is-open'), true);
  assert.equal(document.body.classList.contains('no-scroll'), true);
  assert.equal(document.querySelectorAll('#cart-items .line').length, 2);
  // 2*10.99 + 22.30 = 44.28 ; tax 3.54 ; shipping 5.99 ; total 53.81
  assert.equal($('sum-subtotal').textContent, '$44.28'); assert.equal($('sum-tax').textContent, '$3.54');
  assert.equal($('sum-shipping').textContent, '$5.99'); assert.equal($('sum-total').textContent, '$53.81');
  assert.match($('ship-text').textContent, /\$5\.72 more/);
  document.querySelector('[data-action="inc"][data-id="1"]').click();
  assert.equal($('sum-subtotal').textContent, '$66.58'); assert.equal($('sum-shipping').textContent, 'Free');
  assert.equal($('ship-bar').style.width, '100%');
  document.querySelector('[data-action="dec"][data-id="1"]').click();
  document.querySelector('[data-action="rm"][data-id="3"]').click();
  assert.equal($('cart-badge').textContent, '1');
  assert.equal(JSON.parse(localStorage.getItem('pinkbloom.cart.v1')).length, 1);
});
test('drawer closes via Escape, close button, backdrop; clicks inside do not close', async () => {
  $('cart-drawer').click(); assert.equal($('cart-overlay').classList.contains('is-open'), true);
  key('Escape'); assert.equal($('cart-overlay').classList.contains('is-open'), false);
  assert.equal(document.body.classList.contains('no-scroll'), false);
  $('cart-button').click(); $('cart-close').click(); assert.equal($('cart-overlay').classList.contains('is-open'), false);
  $('cart-button').click(); document.querySelector('#cart-overlay [data-backdrop]').click();
  assert.equal($('cart-overlay').classList.contains('is-open'), false);
});
test('checkout: validation errors, duplicate-submit guard, confirmation, cart cleared', async () => {
  $('cart-button').click(); $('checkout-btn').click();
  assert.equal($('checkout-overlay').classList.contains('is-open'), true);
  assert.equal($('cart-overlay').classList.contains('is-open'), false);
  assert.equal($('co-total').textContent, '$30.07'); // 22.30 + 1.78 + 5.99
  $('checkout-form').dispatchEvent(new window.Event('submit', { cancelable: true, bubbles: true }));
  assert.equal(document.querySelectorAll('.field__err:not([hidden])').length, 5);
  assert.equal(document.activeElement, $('co-name'));
  $('co-name').value = 'Ann Lee'; $('co-email').value = 'bad'; $('co-address').value = '12 Rose Street'; $('co-city').value = 'Coimbatore'; $('co-postal').value = '641001';
  $('checkout-form').dispatchEvent(new window.Event('submit', { cancelable: true, bubbles: true }));
  assert.match($('err-email').textContent, /valid email/);
  $('co-email').value = 'ann@example.com';
  const submit = () => $('checkout-form').dispatchEvent(new window.Event('submit', { cancelable: true, bubbles: true }));
  submit(); submit(); assert.equal($('checkout-submit').disabled, true);
  await sleep(1000);
  assert.equal($('checkout-success').hidden, false);
  assert.match($('order-ref').textContent, /^PB-[A-Z0-9]+-[A-F0-9]{6}$/);
  assert.equal($('order-total').textContent, '$30.07');
  assert.equal($('cart-badge').hidden, true);
  assert.equal(localStorage.getItem('pinkbloom.cart.v1'), '[]');
  $('order-continue').click(); assert.equal($('checkout-overlay').classList.contains('is-open'), false);
  assert.equal($('checkout-form-view').hidden, false);
});
test('mobile menu toggles; no unexpected console errors', () => {
  $('nav-toggle').click(); assert.equal($('nav-toggle').getAttribute('aria-expanded'), 'true');
  key('Escape'); assert.equal($('nav-toggle').getAttribute('aria-expanded'), 'false');
  const unexpected = errors.filter((e) => !String(e[0]).includes('could not load products'));
  console.warn = origWarn; console.error = origErr;
  assert.deepEqual(unexpected, []);
});
test.after(() => window.close());
