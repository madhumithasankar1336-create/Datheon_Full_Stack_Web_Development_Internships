import { loadProducts, loadCategories } from './api.js';
import { filterProducts, hasRatings, createProductCard } from './products.js';
import * as cart from './cart.js';
import { calculateBreakdown, calculateLineTotal } from './calculations.js';
import { initCheckout, openCheckout } from './checkout.js';
import { el, formatPrice, titleCase, truncate, debounce, createOverlay, safeImage, showToast } from './utils.js';

const $ = (id) => {
  const node = document.getElementById(id);
  if (!node) throw new Error(`Missing element #${id} in index.html`);
  return node;
};
const state = { products: [], categories: [], category: 'all', query: '', sort: 'featured' };

/* ---------- product area ---------- */
function setStatus(message, actions = []) {
  const box = $('product-status');
  box.replaceChildren();
  box.hidden = !message;
  if (message) box.append(el('p', { text: message }), ...actions);
}

function renderSkeleton() {
  $('product-grid').setAttribute('aria-busy', 'true');
  $('product-grid').replaceChildren(
    ...Array.from({ length: 8 }, () =>
      el('div', { class: 'card skeleton', 'aria-hidden': 'true' }, el('div', { class: 'sk sk--img' }), el('div', { class: 'sk sk--line' }), el('div', { class: 'sk sk--line sk--short' }))
    )
  );
}

function handleAdd(p) {
  const ok = cart.addToCart(p);
  showToast(ok ? `Added “${truncate(p.title, 34)}” to your bag` : 'You have reached the maximum quantity for this item.');
}

function update() {
  const list = filterProducts(state.products, state);
  const grid = $('product-grid');
  grid.setAttribute('aria-busy', 'false');
  grid.replaceChildren(...list.map((p) => createProductCard(p, { onAdd: handleAdd })));
  $('result-count').textContent = `Showing ${list.length} of ${state.products.length} products`;
  if (list.length === 0 && state.products.length > 0) {
    setStatus('No products match your search. Try a different word or clear your filters.', [
      el('button', { type: 'button', class: 'btn btn--ghost btn--sm', text: 'Clear search & filters', onClick: resetFilters }),
    ]);
  } else setStatus('');
}

function syncChips() {
  document.querySelectorAll('#category-filters .chip').forEach((chip) => {
    const on = chip.dataset.category === state.category;
    chip.classList.toggle('is-active', on);
    chip.setAttribute('aria-pressed', String(on));
  });
}

function setCategory(c) {
  state.category = c;
  syncChips();
  update();
}

function resetFilters() {
  state.query = '';
  state.category = 'all';
  $('search-input').value = '';
  $('search-clear').hidden = true;
  syncChips();
  update();
}

function buildFilters() {
  const box = $('category-filters');
  const all = ['all', ...state.categories];
  box.replaceChildren(
    ...all.map((c) =>
      el('button', { type: 'button', class: 'chip', 'data-category': c, 'aria-pressed': 'false', onClick: () => setCategory(c), text: c === 'all' ? 'All Products' : titleCase(c) })
    )
  );
  const rating = $('sort-select').querySelector('option[value="rating-desc"]');
  rating.disabled = !hasRatings(state.products);
  if (rating.disabled && state.sort === 'rating-desc') {
    state.sort = 'featured';
    $('sort-select').value = 'featured';
  }
  syncChips();
  buildNavMenu();
}

function closeCats() {
  $('nav-cat-list').hidden = true;
  $('nav-cat-toggle').setAttribute('aria-expanded', 'false');
}

function buildNavMenu() {
  $('nav-cat-list').replaceChildren(
    ...['all', ...state.categories].map((c) =>
      el('li', {}, el('button', { type: 'button', class: 'menu-item', text: c === 'all' ? 'All Products' : titleCase(c), onClick: () => {
        setCategory(c);
        closeCats();
        $('nav-links').classList.remove('is-open');
        $('nav-toggle').setAttribute('aria-expanded', 'false');
        $('shop').scrollIntoView();
      } }))
    )
  );
}

function buildCollections() {
  $('collection-grid').replaceChildren(
    ...state.categories.map((c) => {
      const items = state.products.filter((p) => p.category === c);
      const cover = items.find((p) => p.image);
      return el(
        'button',
        { type: 'button', class: 'tile', onClick: () => { setCategory(c); $('shop').scrollIntoView(); } },
        el('span', { class: 'tile__img' }, safeImage(cover?.image, `${titleCase(c)} collection`)),
        el('span', { class: 'tile__name', text: titleCase(c) }),
        el('span', { class: 'tile__count', text: `${items.length} ${items.length === 1 ? 'piece' : 'pieces'}` })
      );
    })
  );
}

function fillHero() {
  const picks = [];
  const cats = new Set();
  for (const p of state.products) {
    if (p.image && !cats.has(p.category) && picks.length < 3) { cats.add(p.category); picks.push(p); }
  }
  picks.forEach((p, i) => {
    const frame = document.querySelector(`.frame--${i + 1}`);
    if (frame) frame.replaceChildren(safeImage(p.image, p.title));
  });
}

async function boot(force = false) {
  renderSkeleton();
  setStatus('');
  try {
    const [products, cats] = await Promise.all([
      loadProducts({ force }),
      loadCategories({ force }).catch((err) => {
        console.warn('PINK BLOOM: categories unavailable, deriving from products:', err.message);
        return [];
      }),
    ]);
    state.products = products;
    const present = [...new Set(products.map((p) => p.category))];
    state.categories = [...cats.filter((c) => present.includes(c)), ...present.filter((c) => !cats.includes(c))];
    if (products.length === 0) {
      $('product-grid').replaceChildren();
      $('product-grid').setAttribute('aria-busy', 'false');
      $('result-count').textContent = '';
      setStatus('The store returned no products right now.', [el('button', { type: 'button', class: 'btn btn--primary btn--sm', text: 'Try again', onClick: () => boot(true) })]);
      return;
    }
    buildFilters();
    buildCollections();
    fillHero();
    update();
  } catch (err) {
    console.error('PINK BLOOM: could not load products', err);
    $('product-grid').replaceChildren();
    $('product-grid').setAttribute('aria-busy', 'false');
    $('result-count').textContent = '';
    setStatus(`We couldn't load the products (${err.message}). Please check your connection.`, [
      el('button', { type: 'button', id: 'retry-btn', class: 'btn btn--primary btn--sm', text: 'Retry', onClick: () => boot(true) }),
    ]);
  }
}

/* ---------- cart drawer ---------- */
function renderCart(items) {
  const count = items.reduce((s, i) => s + i.quantity, 0);
  const badge = $('cart-badge');
  if (badge.textContent !== String(count)) {
    badge.textContent = String(count);
    badge.classList.remove('bump');
    void badge.offsetWidth;
    badge.classList.add('bump');
  }
  badge.hidden = count === 0;
  $('cart-button').setAttribute('aria-label', `Open shopping bag, ${count} ${count === 1 ? 'item' : 'items'}`);

  const focused = document.activeElement?.dataset?.action ? { a: document.activeElement.dataset.action, id: document.activeElement.dataset.id } : null;
  const empty = items.length === 0;
  $('cart-empty').hidden = !empty;
  $('cart-footer').hidden = empty;
  $('cart-items').hidden = empty;
  $('cart-items').replaceChildren(
    ...items.map((i) => {
      const btn = (action, label, text, extra = {}) =>
        el('button', { type: 'button', class: 'qty-btn', 'data-action': action, 'data-id': i.id, 'aria-label': `${label} ${i.title}`, text, ...extra });
      return el(
        'li',
        { class: 'line' },
        el('div', { class: 'line__img' }, safeImage(i.image, i.title)),
        el(
          'div',
          { class: 'line__info' },
          el('p', { class: 'line__title', text: i.title }),
          el('p', { class: 'line__unit', text: `${formatPrice(i.price)} each` }),
          el(
            'div',
            { class: 'qty' },
            btn('dec', 'Decrease quantity of', '−', { disabled: i.quantity <= 1, onClick: () => cart.decreaseQuantity(i.id) }),
            el('span', { class: 'qty__n', 'aria-live': 'polite', 'aria-label': `Quantity ${i.quantity}`, text: String(i.quantity) }),
            btn('inc', 'Increase quantity of', '+', { onClick: () => cart.increaseQuantity(i.id) })
          )
        ),
        el(
          'div',
          { class: 'line__side' },
          el('p', { class: 'line__total', text: formatPrice(calculateLineTotal(i.price, i.quantity)) }),
          el('button', { type: 'button', class: 'link-btn', 'data-action': 'rm', 'data-id': i.id, 'aria-label': `Remove ${i.title} from bag`, text: 'Remove', onClick: () => cart.removeFromCart(i.id) })
        )
      );
    })
  );
  if (focused) {
    const again = document.querySelector(`#cart-items [data-action="${focused.a}"][data-id="${focused.id}"]:not([disabled])`);
    if (again) again.focus();
  }
  const b = calculateBreakdown(items);
  $('sum-subtotal').textContent = formatPrice(b.subtotal);
  $('sum-tax').textContent = formatPrice(b.tax);
  $('sum-shipping').textContent = b.shipping === 0 ? 'Free' : formatPrice(b.shipping);
  $('sum-total').textContent = formatPrice(b.total);
  $('ship-text').textContent = empty ? '' : b.remainingForFree > 0 ? `Add ${formatPrice(b.remainingForFree)} more for free shipping` : 'You’ve unlocked free shipping!';
  $('ship-bar').style.width = `${Math.round(b.progress * 100)}%`;
  $('ship-track').setAttribute('aria-valuenow', String(Math.round(b.progress * 100)));
}

/* ---------- wiring ---------- */
function init() {
  const drawer = createOverlay($('cart-overlay'), { panel: $('cart-drawer') });
  $('cart-button').addEventListener('click', drawer.open);
  $('cart-close').addEventListener('click', drawer.close);
  $('continue-empty').addEventListener('click', () => { drawer.close(); $('shop').scrollIntoView(); });
  $('continue-footer').addEventListener('click', drawer.close);
  $('clear-cart').addEventListener('click', () => { cart.clearCart(); showToast('Your bag has been cleared.'); });
  initCheckout();
  $('checkout-btn').addEventListener('click', () => {
    if (cart.getCount() === 0) return showToast('Your bag is empty — add something first.');
    drawer.close();
    openCheckout();
  });
  cart.subscribe(renderCart);

  const toggle = $('nav-toggle');
  const links = $('nav-links');
  const setMenu = (open) => { links.classList.toggle('is-open', open); toggle.setAttribute('aria-expanded', String(open)); };
  toggle.addEventListener('click', () => setMenu(!links.classList.contains('is-open')));
  links.addEventListener('click', (e) => { if (e.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && links.classList.contains('is-open')) { setMenu(false); toggle.focus(); } });

  const catBtn = $('nav-cat-toggle');
  catBtn.addEventListener('click', () => {
    const open = $('nav-cat-list').hidden;
    $('nav-cat-list').hidden = !open;
    catBtn.setAttribute('aria-expanded', String(open));
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('.has-menu')) closeCats(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('nav-cat-list').hidden) { closeCats(); catBtn.focus(); } });

  const input = $('search-input');
  const onSearch = debounce(() => { state.query = input.value; update(); }, 120);
  input.addEventListener('input', () => { $('search-clear').hidden = !input.value; onSearch(); });
  $('search-form').addEventListener('submit', (e) => { e.preventDefault(); state.query = input.value; update(); $('shop').scrollIntoView(); });
  $('search-clear').addEventListener('click', () => { input.value = ''; $('search-clear').hidden = true; state.query = ''; update(); input.focus(); });
  $('sort-select').addEventListener('change', (e) => { state.sort = e.target.value; update(); });

  window.addEventListener('error', (e) => { console.error('PINK BLOOM unexpected error:', e.error || e.message); showToast('Something unexpected happened. Please try again.'); });
  window.addEventListener('unhandledrejection', (e) => { console.error('PINK BLOOM unhandled rejection:', e.reason); showToast('Something unexpected happened. Please try again.'); });
  $('year').textContent = String(new Date().getFullYear());
  return boot();
}

export const ready = init();
