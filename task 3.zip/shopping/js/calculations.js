// Money maths. Everything is done in integer cents to avoid floating-point drift.
export const TAX_RATE = 0.08;
export const FREE_SHIPPING_THRESHOLD = 50;
export const FLAT_SHIPPING = 5.99;
export const MAX_QTY = 99;

const toCents = (v) => {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) : 0;
};
const toQty = (v) => {
  const n = Number(v);
  return Number.isInteger(n) && n > 0 ? n : 0;
};
const subtotalCents = (items) =>
  (Array.isArray(items) ? items : []).reduce((sum, i) => sum + toCents(i?.price) * toQty(i?.quantity), 0);
const shippingCents = (sub) => (sub <= 0 ? 0 : sub < FREE_SHIPPING_THRESHOLD * 100 ? Math.round(FLAT_SHIPPING * 100) : 0);

export const calculateLineTotal = (price, quantity) => (toCents(price) * toQty(quantity)) / 100;
export const calculateSubtotal = (items) => subtotalCents(items) / 100;
export const calculateTax = (items) => Math.round(subtotalCents(items) * TAX_RATE) / 100;
export const calculateShipping = (items) => shippingCents(subtotalCents(items)) / 100;
export function calculateTotal(items) {
  const sub = subtotalCents(items);
  return (sub + Math.round(sub * TAX_RATE) + shippingCents(sub)) / 100;
}
export function calculateBreakdown(items) {
  const subtotal = calculateSubtotal(items);
  return {
    subtotal,
    tax: calculateTax(items),
    shipping: calculateShipping(items),
    total: calculateTotal(items),
    remainingForFree: subtotal > 0 ? Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal) : FREE_SHIPPING_THRESHOLD,
    progress: Math.min(1, subtotal / FREE_SHIPPING_THRESHOLD),
  };
}
