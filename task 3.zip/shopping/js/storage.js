import { MAX_QTY } from './calculations.js';

export const CART_KEY = 'pinkbloom.cart.v1';

export function sanitizeItem(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const id = Number(raw.id);
  const price = Number(raw.price);
  const quantity = Number(raw.quantity);
  if (!Number.isFinite(id) || !Number.isFinite(price) || price < 0) return null;
  if (!Number.isInteger(quantity) || quantity < 1) return null;
  return {
    id,
    price,
    quantity: Math.min(quantity, MAX_QTY),
    title: typeof raw.title === 'string' && raw.title.trim() ? raw.title.trim() : 'Untitled product',
    image: typeof raw.image === 'string' ? raw.image : '',
    category: typeof raw.category === 'string' ? raw.category : '',
  };
}

export function loadCart() {
  try {
    const raw = localStorage.getItem(CART_KEY);
    if (!raw) return [];
    const data = JSON.parse(raw);
    if (!Array.isArray(data)) throw new Error('saved cart is not a list');
    const merged = new Map();
    for (const entry of data) {
      const item = sanitizeItem(entry);
      if (!item) continue;
      const existing = merged.get(item.id);
      if (existing) existing.quantity = Math.min(existing.quantity + item.quantity, MAX_QTY);
      else merged.set(item.id, item);
    }
    return [...merged.values()];
  } catch (err) {
    console.warn('PINK BLOOM: ignoring unreadable saved cart:', err.message);
    try {
      localStorage.removeItem(CART_KEY);
    } catch (removeErr) {
      console.warn('PINK BLOOM: could not clear saved cart:', removeErr.message);
    }
    return [];
  }
}

export function saveCart(items) {
  try {
    localStorage.setItem(CART_KEY, JSON.stringify(items));
    return true;
  } catch (err) {
    console.warn('PINK BLOOM: could not save cart:', err.message);
    return false;
  }
}
