import * as cart from './cart.js';
import { calculateBreakdown, calculateLineTotal } from './calculations.js';
import { createOverlay, el, formatPrice, showToast } from './utils.js';

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const FIELDS = ['name', 'email', 'address', 'city', 'postal'];

export function validateCheckout(v) {
  const errors = {};
  const t = (k) => String(v?.[k] ?? '').trim();
  if (t('name').length < 2) errors.name = 'Please enter your full name.';
  if (!t('email')) errors.email = 'Please enter your email address.';
  else if (!EMAIL_RE.test(t('email'))) errors.email = 'Please enter a valid email, like name@example.com.';
  if (t('address').length < 5) errors.address = 'Please enter your shipping address.';
  if (t('city').length < 2) errors.city = 'Please enter your city.';
  if (!t('postal')) errors.postal = 'Please enter your postal code.';
  else if (!/^[A-Za-z0-9][A-Za-z0-9 -]{2,9}$/.test(t('postal'))) errors.postal = 'Please enter a valid postal code.';
  return errors;
}

export function generateOrderRef() {
  const bytes = new Uint8Array(3);
  if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(bytes);
  else bytes.forEach((_, i) => (bytes[i] = Math.floor(Math.random() * 256)));
  const rand = [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('').toUpperCase();
  return `PB-${Date.now().toString(36).toUpperCase()}-${rand}`;
}

let overlay;
let submitting = false;
const $ = (id) => document.getElementById(id);

function renderSummary() {
  const items = cart.getItems();
  const b = calculateBreakdown(items);
  $('checkout-lines').replaceChildren(
    ...items.map((i) =>
      el('li', {}, el('span', { text: `${i.title} × ${i.quantity}` }), el('span', { text: formatPrice(calculateLineTotal(i.price, i.quantity)) }))
    )
  );
  $('co-subtotal').textContent = formatPrice(b.subtotal);
  $('co-tax').textContent = formatPrice(b.tax);
  $('co-shipping').textContent = b.shipping === 0 ? 'Free' : formatPrice(b.shipping);
  $('co-total').textContent = formatPrice(b.total);
}

function showErrors(errors) {
  for (const f of FIELDS) {
    const input = $(`co-${f}`);
    const msg = $(`err-${f}`);
    msg.textContent = errors[f] || '';
    msg.hidden = !errors[f];
    if (errors[f]) input.setAttribute('aria-invalid', 'true');
    else input.removeAttribute('aria-invalid');
  }
}

function resetView() {
  $('checkout-form-view').hidden = false;
  $('checkout-success').hidden = true;
  showErrors({});
}

export function openCheckout() {
  if (cart.getItems().length === 0) {
    showToast('Your bag is empty — add something first.');
    return false;
  }
  resetView();
  renderSummary();
  overlay.open();
  return true;
}

export function initCheckout() {
  overlay = createOverlay($('checkout-overlay'), { panel: $('checkout-modal'), onClose: resetView });
  const form = $('checkout-form');
  const submitBtn = $('checkout-submit');
  for (const id of ['checkout-close', 'checkout-cancel', 'order-continue']) $(id).addEventListener('click', () => overlay.close());

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (submitting) return;
    const items = cart.getItems();
    if (items.length === 0) {
      showToast('Your bag is empty — add something first.');
      overlay.close();
      return;
    }
    const values = Object.fromEntries(FIELDS.map((f) => [f, $(`co-${f}`).value]));
    const errors = validateCheckout(values);
    showErrors(errors);
    const firstBad = FIELDS.find((f) => errors[f]);
    if (firstBad) {
      $(`co-${firstBad}`).focus();
      return;
    }
    submitting = true;
    submitBtn.disabled = true;
    submitBtn.textContent = 'Placing order…';
    try {
      await new Promise((resolve) => setTimeout(resolve, 800)); // simulated processing
      const total = calculateBreakdown(items).total;
      const ref = generateOrderRef();
      cart.clearCart();
      $('order-ref').textContent = ref;
      $('order-total').textContent = formatPrice(total);
      $('order-email').textContent = values.email.trim();
      $('checkout-form-view').hidden = true;
      $('checkout-success').hidden = false;
      form.reset();
      $('order-continue').focus();
    } catch (err) {
      console.error('PINK BLOOM: checkout failed', err);
      showToast('Something went wrong placing your demo order. Please try again.');
    } finally {
      submitting = false;
      submitBtn.disabled = false;
      submitBtn.textContent = 'Place Demo Order';
    }
  });
}
