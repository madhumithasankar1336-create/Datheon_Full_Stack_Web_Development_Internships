export const FALLBACK_IMAGE =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><rect width="200" height="200" fill="#FFE8EF"/><text x="100" y="106" font-size="15" text-anchor="middle" fill="#D4146C" font-family="Georgia,serif">PINK BLOOM</text></svg>'
  );

const money = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' });
export const formatPrice = (n) => money.format(Number.isFinite(n) ? n : 0);
export const normalize = (s) => String(s ?? '').toLowerCase().replace(/\s+/g, ' ').trim();
export const titleCase = (s) => String(s ?? '').replace(/\b\w/g, (c) => c.toUpperCase());
export const truncate = (s, n = 42) => (s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s);

export function debounce(fn, ms = 120) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

// Safe element builder: text is always set via textContent / text nodes, never innerHTML.
export function el(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === 'class') node.className = v;
    else if (k === 'text') node.textContent = v;
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
    else node.setAttribute(k, v === true ? '' : String(v));
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    node.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return node;
}

export function safeImage(src, alt) {
  const img = el('img', { alt, loading: 'lazy', decoding: 'async' });
  img.addEventListener('error', () => {
    if (img.src !== FALLBACK_IMAGE) img.src = FALLBACK_IMAGE;
  });
  img.src = src || FALLBACK_IMAGE;
  return img;
}

let toastTimer;
export function showToast(message) {
  const box = document.getElementById('toast');
  if (!box) return;
  box.textContent = message;
  box.classList.add('is-visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => box.classList.remove('is-visible'), 2600);
}

let locks = 0;
const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled])';

// Shared behaviour for the cart drawer and checkout modal: Escape, backdrop click,
// focus trap, focus restore and background scroll lock.
export function createOverlay(root, { panel, onClose } = {}) {
  let opener = null;
  let isOpen = false;
  function onKey(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      close();
    } else if (e.key === 'Tab') {
      const f = [...panel.querySelectorAll(FOCUSABLE)].filter((n) => !n.closest('[hidden]'));
      if (!f.length) return;
      const first = f[0];
      const last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  }
  function open() {
    if (isOpen) return;
    isOpen = true;
    opener = document.activeElement;
    root.removeAttribute('inert');
    root.setAttribute('aria-hidden', 'false');
    root.classList.add('is-open');
    if (locks++ === 0) document.body.classList.add('no-scroll');
    document.addEventListener('keydown', onKey);
    setTimeout(() => {
      if (!isOpen) return;
      const target = panel.querySelector('[data-autofocus]') || panel.querySelector(FOCUSABLE);
      if (target) target.focus();
    }, 40);
  }
  function close() {
    if (!isOpen) return;
    isOpen = false;
    root.classList.remove('is-open');
    root.setAttribute('aria-hidden', 'true');
    root.setAttribute('inert', '');
    locks = Math.max(0, locks - 1);
    if (locks === 0) document.body.classList.remove('no-scroll');
    document.removeEventListener('keydown', onKey);
    if (opener && typeof opener.focus === 'function') opener.focus();
    if (onClose) onClose();
  }
  root.addEventListener('click', (e) => {
    if (e.target === root || e.target.hasAttribute('data-backdrop')) close();
  });
  return { open, close, isOpen: () => isOpen };
}
