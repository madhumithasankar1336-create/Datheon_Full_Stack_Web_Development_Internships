import { EXTRA_PRODUCTS } from './catalog.js';

const BASE = 'https://fakestoreapi.com';
let productsPromise = null;
let categoriesPromise = null;

async function getJson(path) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  try {
    const res = await fetch(BASE + path, { signal: controller.signal, headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error(`The server responded with status ${res.status}`);
    return await res.json();
  } catch (err) {
    if (err && err.name === 'AbortError') throw new Error('The request timed out');
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

export function normalizeProduct(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const id = Number(raw.id);
  const price = Number(raw.price);
  if (!Number.isFinite(id) || !Number.isFinite(price) || price < 0) return null;
  const rate = Number(raw.rating?.rate);
  const count = Number(raw.rating?.count);
  return {
    id,
    price,
    title: typeof raw.title === 'string' && raw.title.trim() ? raw.title.trim() : 'Untitled product',
    category: typeof raw.category === 'string' && raw.category.trim() ? raw.category.trim() : 'uncategorized',
    image: typeof raw.image === 'string' && /^(https?:\/\/|data:image\/svg\+xml)/i.test(raw.image) ? raw.image : '',
    description: typeof raw.description === 'string' ? raw.description : '',
    rating: Number.isFinite(rate) && rate >= 0 && rate <= 5 ? { rate, count: Number.isFinite(count) && count >= 0 ? count : 0 } : null,
  };
}

export function loadProducts({ force = false } = {}) {
  if (!productsPromise || force) {
    productsPromise = getJson('/products')
      .then((data) => {
        if (!Array.isArray(data)) throw new Error('The product list came back in an unexpected format');
        const seen = new Set();
        return [...data, ...EXTRA_PRODUCTS].map(normalizeProduct).filter((p) => p && !seen.has(p.id) && seen.add(p.id));
      })
      .catch((err) => {
        productsPromise = null; // allow a retry
        throw err;
      });
  }
  return productsPromise;
}

export function loadCategories({ force = false } = {}) {
  if (!categoriesPromise || force) {
    categoriesPromise = getJson('/products/categories')
      .then((data) => {
        if (!Array.isArray(data)) throw new Error('The category list came back in an unexpected format');
        return data.filter((c) => typeof c === 'string' && c.trim()).map((c) => c.trim());
      })
      .catch((err) => {
        categoriesPromise = null;
        throw err;
      });
  }
  return categoriesPromise;
}
