// Extra PINK BLOOM products that complement the FakeStore API items.
// Images are generated SVG tiles (no external requests). Demo data only.
const TILES = {
  beauty: ['#FFD1E3', '#F9A8D4'], 'home decor': ['#F6E6FF', '#E9D5FF'], bags: ['#FFE0EB', '#FFB3CC'],
  footwear: ['#FFF0F5', '#FBCFE8'], accessories: ['#FFE8EF', '#DDD6FE'], gifts: ['#FFECF3', '#FDA4CF'],
};
function tile(emoji, category) {
  const [a, b] = TILES[category];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="200" height="200" rx="24" fill="url(#g)"/><text x="100" y="125" font-size="84" text-anchor="middle">${emoji}</text></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
}
const RAW = {
  beauty: [['Rose Glow Face Serum', 24.99, '🧴'], ['Blush Petal Lip Tint', 12.49, '💄'], ['Pink Clay Face Mask', 18.99, '🌸'], ['Velvet Matte Lipstick Set', 29.99, '💋'], ['Rosewater Setting Mist', 15.49, '💧'], ['Satin Makeup Brush Kit', 34.99, '🖌️']],
  'home decor': [['Blush Ceramic Vase', 39.99, '🏺'], ['Rose Scented Candle', 21.99, '🕯️'], ['Pink Velvet Cushion', 27.49, '🛋️'], ['Bloom Wall Mirror', 64.99, '🪞'], ['Pastel Table Lamp', 49.99, '💡'], ['Floral Photo Frame Set', 23.99, '🖼️']],
  bags: [['Blush Mini Tote', 45.99, '👜'], ['Pink Quilted Crossbody', 58.99, '👛'], ['Petal Canvas Backpack', 42.49, '🎒'], ['Satin Evening Clutch', 36.99, '👝'], ['Weekend Duffel Bag', 79.99, '🧳'], ['Everyday Shopper Bag', 31.99, '🛍️']],
  footwear: [['Blush Ballet Flats', 54.99, '🩰'], ['Rose Platform Sneakers', 69.99, '👟'], ['Pearl Strap Sandals', 48.99, '👡'], ['Pink Suede Boots', 89.99, '👢'], ['Cloud Slip-On Slides', 25.99, '🩴'], ['Satin Kitten Heels', 64.49, '👠']],
  accessories: [['Pink Tinted Sunglasses', 31.99, '🕶️'], ['Hair Scrunchie Set', 13.99, '🎀'], ['Blossom Printed Scarf', 26.99, '🧣'], ['Pearl Hair Clips', 11.99, '✨'], ['Wide Brim Straw Hat', 33.99, '👒'], ['Rose Gold Wristwatch', 119.99, '⌚']],
  gifts: [['Bloom Gift Box', 49.99, '🎁'], ['Dried Flower Bouquet', 28.99, '💐'], ['Pink Tea Sampler', 22.49, '🍵'], ['Macaron Treat Box', 24.49, '🍬'], ['Personalised Journal', 19.49, '📓'], ['Mini Plant Pot', 16.99, '🪴']],
};
let nextId = 101;
export const EXTRA_PRODUCTS = Object.entries(RAW).flatMap(([category, list]) =>
  list.map(([title, price, emoji]) => ({
    id: nextId++, title, price, category, image: tile(emoji, category), rating: null,
    description: `${title} — part of the PINK BLOOM ${category} collection (demo product).`,
  }))
);
