import * as calc from './calculations.js';
import { loadCart, saveCart } from './storage.js';

let items = loadCart();
const listeners = new Set();

export const getItems = () => items.map((i) => ({ ...i }));
export const getCount = () => items.reduce((s, i) => s + i.quantity, 0);

function commit() {
  saveCart(items);
  for (const fn of listeners) {
    try {
      fn(getItems());
    } catch (err) {
      console.error('PINK BLOOM: cart listener failed:', err);
    }
  }
}

export function subscribe(fn) {
  listeners.add(fn);
  fn(getItems());
  return () => listeners.delete(fn);
}

export function addToCart(product) {
  const id = Number(product?.id);
  const price = Number(product?.price);
  if (!Number.isFinite(id) || !Number.isFinite(price) || price < 0) return false;
  const existing = items.find((i) => i.id === id);
  if (existing) {
    if (existing.quantity >= calc.MAX_QTY) return false;
    existing.quantity += 1;
  } else {
    items.push({
      id,
      price,
      quantity: 1,
      title: product.title || 'Untitled product',
      image: product.image || '',
      category: product.category || '',
    });
  }
  commit();
  return true;
}

export function removeFromCart(productId) {
  const before = items.length;
  items = items.filter((i) => i.id !== Number(productId));
  if (items.length !== before) commit();
  return items.length !== before;
}

export function updateQuantity(productId, quantity) {
  const n = Number(quantity);
  const item = items.find((i) => i.id === Number(productId));
  if (!item || !Number.isInteger(n)) return false;
  if (n < 1) return removeFromCart(productId);
  item.quantity = Math.min(n, calc.MAX_QTY);
  commit();
  return true;
}

export function increaseQuantity(productId) {
  const item = items.find((i) => i.id === Number(productId));
  return item ? updateQuantity(productId, item.quantity + 1) : false;
}

export function decreaseQuantity(productId) {
  const item = items.find((i) => i.id === Number(productId));
  if (!item || item.quantity <= 1) return false; // use removeFromCart to delete the line
  return updateQuantity(productId, item.quantity - 1);
}

export function clearCart() {
  items = [];
  commit();
}

export const calculateSubtotal = () => calc.calculateSubtotal(items);
export const calculateTax = () => calc.calculateTax(items);
export const calculateShipping = () => calc.calculateShipping(items);
export const calculateTotal = () => calc.calculateTotal(items);
