import { el, normalize, formatPrice, titleCase, safeImage } from './utils.js';

export const hasRatings = (products) => products.some((p) => p.rating && p.rating.count > 0);

export function filterProducts(products, { category = 'all', query = '', sort = 'featured' } = {}) {
  const q = normalize(query);
  const list = products.filter(
    (p) =>
      (category === 'all' || p.category === category) &&
      (!q || normalize(p.title).includes(q) || normalize(p.category).includes(q))
  );
  if (sort === 'price-asc') list.sort((a, b) => a.price - b.price);
  else if (sort === 'price-desc') list.sort((a, b) => b.price - a.price);
  else if (sort === 'rating-desc') list.sort((a, b) => (b.rating?.rate ?? -1) - (a.rating?.rate ?? -1));
  return list;
}

export function createProductCard(p, { onAdd }) {
  const rating = p.rating
    ? el('p', { class: 'card__rating', 'aria-label': `Rated ${p.rating.rate} out of 5 from ${p.rating.count} reviews` }, `★ ${p.rating.rate.toFixed(1)} `, el('span', { text: `(${p.rating.count})` }))
    : el('p', { class: 'card__rating card__rating--none', text: 'No ratings yet' });
  return el(
    'article',
    { class: 'card' },
    el('div', { class: 'card__media' }, safeImage(p.image, p.title)),
    el(
      'div',
      { class: 'card__body' },
      el('p', { class: 'card__cat', text: titleCase(p.category) }),
      el('h3', { class: 'card__title', text: p.title, title: p.title }),
      rating,
      el(
        'div',
        { class: 'card__foot' },
        el('p', { class: 'card__price', text: formatPrice(p.price) }),
        el('button', { type: 'button', class: 'btn btn--primary btn--sm', 'aria-label': `Add ${p.title} to cart`, onClick: () => onAdd(p), text: 'Add to Cart' })
      )
    )
  );
}
