# TaskFlow – Smart Task Manager & Productivity Tracker

A responsive task manager with an **Aurora Glass** interface, built with HTML5, CSS3 and vanilla JavaScript. No frameworks, no backend: it runs as a static site.

## Problem statement
Everyday tasks end up scattered across notes and chats. TaskFlow gives one place to capture tasks, prioritise them, track deadlines and see progress, with data kept privately in the browser.

## Key features
- Create, read, update and delete tasks (title, description, category, priority, due date, status)
- Validation with clear messages; delete, clear-completed and reset-all all need confirmation
- Dashboard: total, active, completed and overdue counts, completion %, progress bar, due today, recent tasks (all computed from real data)
- Views: Dashboard, All Tasks, Today, Upcoming, Completed, Settings
- Live search (title + description), status / category / priority filters that combine, five sort options, Clear Filters
- Drag-and-drop reordering (native HTML5) plus up/down buttons for touch devices; order is saved
- Dark (default) and light themes, saved between visits
- Toasts, empty states, keyboard support, reduced-motion support

## Aurora Glass design
Deep navy backgrounds with a slow-drifting aurora of teal, blue and violet radial gradients. Cards are translucent glass (`backdrop-filter: blur(18px)`) with thin borders. Teal-to-violet gradients are reserved for the primary button, active filter chips and the progress bar. Priority colours: teal (low), amber (medium), pink-red (high).

## Technologies
HTML5, CSS3 (Grid, Flexbox, custom properties), JavaScript ES6+, localStorage, inline SVG icons, Manrope via Google Fonts (system-font fallback).

## Folder structure
```text
taskflow-aurora-glass/
├── index.html
├── README.md
├── .gitignore
├── css/style.css
├── js/
│   ├── app.js         navigation, theme, drawer, start-up
│   ├── storage.js     localStorage save/load + data validation
│   ├── tasks.js       CRUD, modal, confirm, toasts, rendering, drag-and-drop
│   ├── filters.js     search, filters, sorting
│   └── dashboard.js   statistics
└── assets/icons/favicon.svg
```

## Run locally
1. Download or clone the project.
2. Open `index.html` in a browser (double-click), or serve the folder: `python -m http.server 8000` and visit `http://localhost:8000`.

## How localStorage is used
| Key | Content |
|---|---|
| `taskflow.tasks.v1` | JSON array of tasks. Array order is your custom order. |
| `taskflow.theme` | `dark` or `light` |

Data never leaves your browser. If saved data cannot be parsed, the raw text is copied to `taskflow.tasks.v1.backup` before anything else happens, so it is never silently erased. Invalid individual entries are skipped; valid ones are kept.

## Testing checklist
- [ ] Create a task; it appears immediately and the toast shows
- [ ] Empty title is rejected with a message
- [ ] Edit a task; changes appear and persist
- [ ] Delete asks for confirmation
- [ ] Refresh: tasks and theme remain
- [ ] Search matches title and description
- [ ] Status, category and priority filters work alone and together
- [ ] All five sort options order correctly
- [ ] Dashboard numbers and % update after every action
- [ ] Complete a task, then reopen it
- [ ] A past due date on an active task shows as Overdue; a task due today appears in Today
- [ ] Drag a card (sort = My order); order survives refresh; arrows work too
- [ ] Clear completed and Reset all both ask first
- [ ] Mobile width (< 760px): menu button opens the drawer; no horizontal scroll
- [ ] Browser console shows no errors

## Screenshots
_Add screenshots here (for example `assets/screenshots/dashboard.png`)._

## Links
- GitHub repository: `https://github.com/<your-username>/taskflow-aurora-glass` _(placeholder)_
- Live demo: _add your GitHub Pages URL after deploying_

## Deploy to GitHub Pages
1. Create a **public** repository named `taskflow-aurora-glass` on github.com (don't add a README; you already have one).
2. In the project folder run:
   ```bash
   git init
   git add .
   git commit -m "Add TaskFlow Aurora Glass"
   git branch -M main
   git remote add origin https://github.com/<your-username>/taskflow-aurora-glass.git
   git push -u origin main
   ```
   (No Git? Use **Add file → Upload files** on GitHub and drag in everything, keeping the folders.)
3. Repository **Settings → Pages**: Source = *Deploy from a branch*, Branch = `main`, folder = `/ (root)`, Save.
4. After a minute the site is at `https://<your-username>.github.io/taskflow-aurora-glass/`. Paste that into the Live demo line above.

## Submit to the internship portal
Submit two links: the public repository URL and the live GitHub Pages URL. Open both in a private window first to confirm they load.

## Future improvements
Export/import JSON, recurring tasks, subtasks, reminders, tags, calendar view, installable PWA.
