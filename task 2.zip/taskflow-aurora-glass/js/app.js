'use strict';
/* App bootstrap: navigation, theme, drawer, settings. */
function showView(v) {
  TF.view = v;
  const isList = !!VIEW_TITLES[v];
  $('#view-dashboard').hidden = v !== 'dashboard';
  $('#view-tasks').hidden = !isList;
  $('#view-settings').hidden = v !== 'settings';
  document.querySelectorAll('.nav[data-view]').forEach(b => {
    const on = b.dataset.view === v;
    b.classList.toggle('active', on);
    on ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current');
  });
  if (isList) {
    $('#statusChips').hidden = v !== 'all';
    if (v !== 'all') TF.f.status = 'all';
    syncFilterUI(); renderTasks();
  }
  closeDrawer();
}

function setTheme(t) {
  document.documentElement.dataset.theme = t;
  saveTheme(t);
  $('#themeLabel').textContent = t === 'dark' ? 'Light theme' : 'Dark theme';
  $('#themeBtn use').setAttribute('href', t === 'dark' ? '#i-sun' : '#i-moon');
}
const toggleTheme = () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');

function openDrawer() { $('#sidebar').classList.add('open'); $('#scrim').classList.add('show'); $('#menuBtn').setAttribute('aria-expanded', 'true'); }
function closeDrawer() { $('#sidebar').classList.remove('open'); $('#scrim').classList.remove('show'); $('#menuBtn').setAttribute('aria-expanded', 'false'); }

document.addEventListener('DOMContentLoaded', () => {
  TF.tasks = loadFromLocalStorage();
  setTheme(loadTheme());
  $('#dateLine').textContent = new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  document.querySelectorAll('.nav[data-view]').forEach(b => b.addEventListener('click', () => showView(b.dataset.view)));
  $('#themeBtn').addEventListener('click', toggleTheme);
  $('#themeBtn3').addEventListener('click', toggleTheme);
  $('#menuBtn').addEventListener('click', openDrawer);
  $('#scrim').addEventListener('click', closeDrawer);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeDrawer(); });

  $('#newBtn').addEventListener('click', () => openTaskModal());
  $('#taskForm').addEventListener('submit', submitTaskForm);
  $('#dlgClose').addEventListener('click', () => $('#taskDlg').close());
  $('#dlgCancel').addEventListener('click', () => $('#taskDlg').close());
  $('#clearDone').addEventListener('click', clearCompleted);
  $('#resetAll').addEventListener('click', resetAll);

  initTaskList(); initFilters();
  showView('dashboard');
  renderTasks(); updateDashboard();
});
