'use strict';
/* Storage layer: all localStorage access lives here. */
const TASKS_KEY = 'taskflow.tasks.v1';
const THEME_KEY = 'taskflow.theme';

const TF = {
  tasks: [],
  view: 'dashboard',
  f: { q: '', status: 'all', cat: 'all', pri: 'all', sort: 'manual' }
};

const CATS = ['Work', 'Personal', 'Study', 'Other'];
const PRIS = ['Low', 'Medium', 'High'];

function isValidTask(t) {
  return t && typeof t === 'object' && typeof t.id === 'string' && typeof t.title === 'string' && t.title.trim() !== '';
}

function normalizeTask(t) {
  return {
    id: t.id,
    title: t.title.trim(),
    description: typeof t.description === 'string' ? t.description : '',
    category: CATS.includes(t.category) ? t.category : 'Other',
    priority: PRIS.includes(t.priority) ? t.priority : 'Medium',
    dueDate: /^\d{4}-\d{2}-\d{2}$/.test(t.dueDate || '') ? t.dueDate : '',
    status: t.status === 'completed' ? 'completed' : 'active',
    createdAt: t.createdAt && !isNaN(Date.parse(t.createdAt)) ? t.createdAt : new Date().toISOString()
  };
}

function saveToLocalStorage() {
  try {
    localStorage.setItem(TASKS_KEY, JSON.stringify(TF.tasks));
    return true;
  } catch (e) {
    toast('Could not save your tasks. Browser storage may be full or blocked.', 'error');
    return false;
  }
}

function loadFromLocalStorage() {
  let raw = null;
  try { raw = localStorage.getItem(TASKS_KEY); } catch (e) { return []; }
  if (!raw) return [];
  try {
    const data = JSON.parse(raw);
    if (!Array.isArray(data)) throw new Error('not an array');
    return data.filter(isValidTask).map(normalizeTask);
  } catch (e) {
    // Never erase user data: keep the unreadable text under a backup key.
    try { localStorage.setItem(TASKS_KEY + '.backup', raw); } catch (_) {}
    setTimeout(() => toast('Saved data was unreadable. A backup copy was kept in your browser.', 'error'), 300);
    return [];
  }
}

function loadTheme() {
  try { const t = localStorage.getItem(THEME_KEY); return t === 'light' ? 'light' : 'dark'; } catch (e) { return 'dark'; }
}
function saveTheme(t) { try { localStorage.setItem(THEME_KEY, t); } catch (e) {} }
