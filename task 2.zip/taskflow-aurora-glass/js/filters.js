'use strict';
/* Search, filters and sorting. */
const PRI_W = { High: 0, Medium: 1, Low: 2 };

function inView(t) {
  const td = todayStr();
  switch (TF.view) {
    case 'today': return t.dueDate === td;
    case 'upcoming': return t.status === 'active' && !!t.dueDate && t.dueDate > td;
    case 'completed': return t.status === 'completed';
    default: return true;
  }
}

function getVisible() {
  const { q, status, cat, pri, sort } = TF.f;
  const needle = q.trim().toLowerCase();
  const out = TF.tasks.filter(t => inView(t)
    && (!needle || t.title.toLowerCase().includes(needle) || t.description.toLowerCase().includes(needle))
    && (cat === 'all' || t.category === cat)
    && (pri === 'all' || t.priority === pri)
    && (status === 'all' || (status === 'overdue' ? isOverdue(t) : t.status === status)));
  const by = {
    newest: (a, b) => b.createdAt.localeCompare(a.createdAt),
    oldest: (a, b) => a.createdAt.localeCompare(b.createdAt),
    due: (a, b) => (a.dueDate || '9999').localeCompare(b.dueDate || '9999') || a.title.localeCompare(b.title),
    priority: (a, b) => PRI_W[a.priority] - PRI_W[b.priority] || (a.dueDate || '9999').localeCompare(b.dueDate || '9999'),
    alpha: (a, b) => a.title.localeCompare(b.title, undefined, { sensitivity: 'base' })
  }[sort];
  return by ? out.slice().sort(by) : out;   // 'manual' keeps the saved array order
}

function syncFilterUI() {
  $('#search').value = TF.f.q;
  $('#fCat').value = TF.f.cat; $('#fPri').value = TF.f.pri; $('#fSort').value = TF.f.sort;
  document.querySelectorAll('#statusChips .chip').forEach(c => {
    const on = c.dataset.status === TF.f.status;
    c.classList.toggle('on', on); c.setAttribute('aria-pressed', on);
  });
}

function initFilters() {
  $('#fCat').addEventListener('change', e => { TF.f.cat = e.target.value; renderTasks(); });
  $('#fPri').addEventListener('change', e => { TF.f.pri = e.target.value; renderTasks(); });
  $('#fSort').addEventListener('change', e => { TF.f.sort = e.target.value; renderTasks(); });
  $('#statusChips').addEventListener('click', e => {
    const c = e.target.closest('.chip'); if (!c) return;
    TF.f.status = c.dataset.status; syncFilterUI(); renderTasks();
  });
  $('#clearF').addEventListener('click', () => {
    TF.f = { q: '', status: 'all', cat: 'all', pri: 'all', sort: 'manual' };
    syncFilterUI(); renderTasks();
  });
  $('#search').addEventListener('input', e => {
    TF.f.q = e.target.value;
    if (!VIEW_TITLES[TF.view]) showView('all');   // searching jumps to the task list
    else renderTasks();
  });
}
