'use strict';
/* Dashboard statistics: always computed from real task data. */
function updateDashboard() {
  const total = TF.tasks.length;
  const done = TF.tasks.filter(t => t.status === 'completed').length;
  const active = total - done;
  const over = TF.tasks.filter(isOverdue).length;
  const pct = total ? Math.round(done / total * 100) : 0;
  const td = todayStr();
  const dueToday = TF.tasks.filter(t => t.dueDate === td && t.status === 'active');

  $('#stTotal').textContent = total; $('#stActive').textContent = active;
  $('#stDone').textContent = done; $('#stOver').textContent = over;
  $('#pctNum').textContent = pct + '%';
  $('#pctTxt').textContent = total ? `${done} of ${total} tasks finished` : 'Add a task to begin';
  $('#barFill').style.width = pct + '%';
  $('#barWrap').setAttribute('aria-valuenow', pct);
  $('#ovDone').textContent = done; $('#ovLeft').textContent = active;

  const li = t => `<li class="${t.status === 'completed' ? 'done' : ''}"><i class="dot pri-${t.priority.toLowerCase()}"></i><span>${esc(t.title)}</span><small class="muted">${t.dueDate ? fmtDate(t.dueDate) : t.category}</small></li>`;
  $('#dueToday').innerHTML = dueToday.length ? dueToday.map(li).join('') : '<li class="muted">Nothing due today.</li>';
  const recent = TF.tasks.slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5);
  $('#recent').innerHTML = recent.length ? recent.map(li).join('') : '<li class="muted">No tasks yet. Create your first one.</li>';

  let msg;
  if (!total) msg = 'A clear slate. Add your first task to get going.';
  else if (over) msg = `${over} task${over > 1 ? 's are' : ' is'} overdue. Start with the oldest.`;
  else if (pct === 100) msg = 'Everything is done. Nice work.';
  else if (dueToday.length) msg = `${dueToday.length} task${dueToday.length > 1 ? 's are' : ' is'} due today.`;
  else msg = `${active} task${active > 1 ? 's' : ''} left. Keep the momentum.`;
  $('#prodMsg').textContent = msg;
}
