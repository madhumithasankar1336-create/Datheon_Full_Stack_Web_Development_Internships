'use strict';
/* Task logic: CRUD, modal, confirm dialog, toasts, rendering. */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = n => String(n).padStart(2, '0');
const todayStr = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const isOverdue = t => t.status === 'active' && !!t.dueDate && t.dueDate < todayStr();
const fmtDate = s => { if (!s) return ''; const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }); };
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const icon = n => `<svg aria-hidden="true"><use href="#i-${n}"/></svg>`;

/* ---------- Toasts ---------- */
function toast(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), 3600);
}

/* ---------- Confirm dialog (returns a Promise<boolean>) ---------- */
function confirmBox(title, msg, okLabel) {
  const dlg = $('#confirmDlg');
  $('#cfTitle').textContent = title;
  $('#cfMsg').textContent = msg;
  $('#cfOk').textContent = okLabel;
  return new Promise(res => {
    dlg.returnValue = 'no';
    dlg.addEventListener('close', () => res(dlg.returnValue === 'yes'), { once: true });
    dlg.showModal();
  });
}

/* ---------- CRUD ---------- */
function commit() { saveToLocalStorage(); renderTasks(); updateDashboard(); }

function addTask(data) {
  TF.tasks.unshift({ id: uid(), ...data, createdAt: new Date().toISOString() });
  commit(); toast('Task created');
}
function updateTask(id, data) {
  const i = TF.tasks.findIndex(t => t.id === id);
  if (i < 0) return;
  TF.tasks[i] = { ...TF.tasks[i], ...data };
  commit(); toast('Task updated');
}
async function deleteTask(id) {
  const t = TF.tasks.find(x => x.id === id);
  if (!t || !(await confirmBox('Delete this task?', `“${t.title}” will be permanently removed.`, 'Delete task'))) return;
  TF.tasks = TF.tasks.filter(x => x.id !== id);
  commit(); toast('Task deleted');
}
function toggleTask(id) {
  const t = TF.tasks.find(x => x.id === id);
  if (!t) return;
  t.status = t.status === 'completed' ? 'active' : 'completed';
  commit(); toast(t.status === 'completed' ? 'Task completed' : 'Task reopened');
}
function moveTask(id, dir) {            // dir: -1 up, +1 down (relative to visible list)
  const ids = getVisible().map(t => t.id);
  const k = ids.indexOf(id), other = ids[k + dir];
  if (k < 0 || !other) return;
  if (TF.f.sort !== 'manual') { TF.f.sort = 'manual'; syncFilterUI(); }
  const a = TF.tasks.findIndex(t => t.id === id), b = TF.tasks.findIndex(t => t.id === other);
  [TF.tasks[a], TF.tasks[b]] = [TF.tasks[b], TF.tasks[a]];
  commit();
}
function dropTask(dragId, targetId) {
  if (dragId === targetId) return;
  const from = TF.tasks.findIndex(t => t.id === dragId);
  const [item] = TF.tasks.splice(from, 1);
  const to = TF.tasks.findIndex(t => t.id === targetId);
  TF.tasks.splice(to, 0, item);
  commit();
}
async function clearCompleted() {
  const n = TF.tasks.filter(t => t.status === 'completed').length;
  if (!n) return toast('There are no completed tasks to clear.', 'error');
  if (!(await confirmBox('Clear completed tasks?', `${n} completed task${n > 1 ? 's' : ''} will be removed.`, 'Clear completed'))) return;
  TF.tasks = TF.tasks.filter(t => t.status !== 'completed');
  commit(); toast('Completed tasks cleared');
}
async function resetAll() {
  if (!TF.tasks.length) return toast('There are no tasks to reset.', 'error');
  if (!(await confirmBox('Reset all tasks?', `All ${TF.tasks.length} tasks will be permanently deleted. This cannot be undone.`, 'Reset everything'))) return;
  TF.tasks = [];
  commit(); toast('All tasks reset');
}

/* ---------- Task modal ---------- */
let editingId = null;
function openTaskModal(id) {
  editingId = id || null;
  const t = id ? TF.tasks.find(x => x.id === id) : null;
  $('#dlgTitle').textContent = t ? 'Edit task' : 'Create new task';
  $('#dlgSave').textContent = t ? 'Save changes' : 'Save task';
  $('#fTitle').value = t ? t.title : '';
  $('#fDesc').value = t ? t.description : '';
  $('#fmCat').value = t ? t.category : 'Work';
  $('#fmPri').value = t ? t.priority : 'Medium';
  $('#fmDue').value = t ? t.dueDate : '';
  $('#fmStatus').value = t ? t.status : 'active';
  $('#titleErr').textContent = ''; $('#dueErr').textContent = '';
  $('#taskDlg').showModal();
  $('#fTitle').focus();
}
function submitTaskForm(e) {
  e.preventDefault();
  const title = $('#fTitle').value.trim(), due = $('#fmDue').value;
  const tErr = !title ? 'Enter a task title.' : '';
  const dErr = due && !/^\d{4}-\d{2}-\d{2}$/.test(due) ? 'Enter a valid due date.' : '';
  $('#titleErr').textContent = tErr; $('#dueErr').textContent = dErr;
  $('#fTitle').setAttribute('aria-invalid', !!tErr);
  if (tErr || dErr) { (tErr ? $('#fTitle') : $('#fmDue')).focus(); return; }
  const data = {
    title, description: $('#fDesc').value.trim(), category: $('#fmCat').value,
    priority: $('#fmPri').value, dueDate: due, status: $('#fmStatus').value
  };
  editingId ? updateTask(editingId, data) : addTask(data);
  $('#taskDlg').close();
}

/* ---------- Rendering ---------- */
function cardHTML(t, manual) {
  const over = isOverdue(t), done = t.status === 'completed';
  const st = done ? 'Completed' : over ? 'Overdue' : 'Active';
  const p = t.priority.toLowerCase();
  return `<article class="task glass pri-${p}${done ? ' done' : ''}${over ? ' over' : ''}" data-id="${esc(t.id)}"${manual ? ' draggable="true"' : ''}>
    <span class="handle${manual ? '' : ' off'}" title="${manual ? 'Drag to reorder' : 'Switch to “My order” to drag'}" aria-hidden="true">${icon('drag')}</span>
    <div class="tbody">
      <h3>${esc(t.title)}</h3>
      ${t.description ? `<p class="desc">${esc(t.description)}</p>` : ''}
      <div class="meta">
        <span class="tag">${esc(t.category)}</span>
        <span class="tag pri">${esc(t.priority)} priority</span>
        <span class="tag">${t.dueDate ? 'Due ' + fmtDate(t.dueDate) : 'No due date'}</span>
        <span class="tag st st-${st.toLowerCase()}">${st}</span>
        <span class="created">Created ${new Date(t.createdAt).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })}</span>
      </div>
    </div>
    <div class="tact">
      <button class="icon-btn" data-act="toggle" aria-label="${done ? 'Reopen' : 'Complete'} task: ${esc(t.title)}" title="${done ? 'Reopen' : 'Mark complete'}">${icon(done ? 'undo' : 'check')}</button>
      <button class="icon-btn" data-act="up" aria-label="Move up" title="Move up">${icon('up')}</button>
      <button class="icon-btn" data-act="down" aria-label="Move down" title="Move down">${icon('down')}</button>
      <button class="icon-btn" data-act="edit" aria-label="Edit task: ${esc(t.title)}" title="Edit">${icon('edit')}</button>
      <button class="icon-btn del" data-act="delete" aria-label="Delete task: ${esc(t.title)}" title="Delete">${icon('trash')}</button>
    </div></article>`;
}

const VIEW_TITLES = { all: 'All Tasks', today: 'Today', upcoming: 'Upcoming', completed: 'Completed' };
function emptyHTML() {
  const filtered = TF.f.q || TF.f.cat !== 'all' || TF.f.pri !== 'all' || TF.f.status !== 'all';
  if (filtered && TF.tasks.length) return `<div class="empty glass"><h3>No matching tasks</h3><p class="muted">Nothing fits these filters. Try a different search or clear the filters.</p></div>`;
  const msgs = {
    all: ['No tasks yet', 'Create your first task to start tracking your day.'],
    today: ['Nothing due today', 'Tasks with today’s due date will appear here.'],
    upcoming: ['No upcoming deadlines', 'Active tasks with a future due date will appear here.'],
    completed: ['No completed tasks yet', 'Finish a task and it will show up here.']
  }[TF.view] || ['No tasks', ''];
  return `<div class="empty glass"><h3>${msgs[0]}</h3><p class="muted">${msgs[1]}</p></div>`;
}
function renderTasks() {
  const list = $('#taskList');
  if (!VIEW_TITLES[TF.view]) return;
  const vis = getVisible(), manual = TF.f.sort === 'manual';
  $('#listTitle').textContent = VIEW_TITLES[TF.view];
  $('#listCount').textContent = `${vis.length} task${vis.length === 1 ? '' : 's'}`;
  $('#dragHint').hidden = !vis.length;
  list.innerHTML = vis.length ? vis.map(t => cardHTML(t, manual)).join('') : emptyHTML();
}

/* One set of listeners for the whole list (event delegation). */
function initTaskList() {
  const list = $('#taskList');
  let dragId = null;
  list.addEventListener('click', e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const id = b.closest('.task').dataset.id, a = b.dataset.act;
    if (a === 'toggle') toggleTask(id);
    else if (a === 'edit') openTaskModal(id);
    else if (a === 'delete') deleteTask(id);
    else if (a === 'up') moveTask(id, -1);
    else if (a === 'down') moveTask(id, 1);
  });
  list.addEventListener('dragstart', e => {
    const c = e.target.closest('.task'); if (!c) return;
    dragId = c.dataset.id; c.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', dragId);
  });
  list.addEventListener('dragover', e => {
    if (!dragId) return; e.preventDefault();
    list.querySelectorAll('.drop').forEach(x => x.classList.remove('drop'));
    const c = e.target.closest('.task'); if (c && c.dataset.id !== dragId) c.classList.add('drop');
  });
  list.addEventListener('drop', e => {
    e.preventDefault();
    const c = e.target.closest('.task');
    if (c && dragId) dropTask(dragId, c.dataset.id);
    dragId = null;
  });
  list.addEventListener('dragend', () => { dragId = null; renderTasks(); });
}
